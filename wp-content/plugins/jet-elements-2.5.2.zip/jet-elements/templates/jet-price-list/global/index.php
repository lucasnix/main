<?php
/**
 * Price list template
 */
?>

<?php $this->_get_global_looped_template( 'price-list', 'price_list' ); ?>