<div class="jet-progress-bar__inner">
	<div class="jet-progress-bar__wrapper">
		<div class="jet-progress-bar__percent"><span class="jet-progress-bar__percent-value">0</span><span class="jet-progress-bar__percent-suffix">&#37;</span></div>
		<div class="jet-progress-bar__status-bar"></div>
	</div>
	<div class="jet-progress-bar__title"><?php
		$this->_icon( 'icon', '<span class="jet-progress-bar__title-icon jet-elements-icon">%s</span>' );
		$this->_html( 'title', '<span class="jet-progress-bar__title-text">%s</span>' );?></div>
</div>
