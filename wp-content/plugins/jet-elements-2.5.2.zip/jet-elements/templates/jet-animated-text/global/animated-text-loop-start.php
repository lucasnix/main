<?php
/**
 * Animated text list start template
 */
?>
<div class="jet-animated-text__animated-text">
